# NFW-004 report

Status: complete

## Enforced security invariants

- Model cannot mint capabilities: **False**
- Model cannot upgrade privilege: **False**
- Neural signal can authorize: **False**
- Default deny: **True**

No external actions were executed. This is a capability-boundary PoC, not a universal neural safety guarantee.

## Limitations
- No real external tools, shell, network, filesystem, or APIs were executed.
- HMAC secret and broker are a reference PoC, not a production trust root or process-isolation design.
- Neural activation demo is not a trained safety score and cannot establish harmful-output prevention.
- Model process isolation, authenticated principals, secure key storage, TOCTOU defenses and deployment review remain required.
- A veto-only monitor can deny legitimate actions; utility and safety tradeoffs need separate evaluation.
- Novelty requires a current literature review; this notebook does not establish priority.
