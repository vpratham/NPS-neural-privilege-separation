# NPS Experiment 012 — Policy Subspace Causal Necessity — Report

## Research Question

Is the policy subspace discovered in Experiment 011 causally necessary for the *linear separability* of benign vs. unsafe activations, or is the same information redundantly encoded elsewhere in the residual stream? This notebook does not test generation-time behavior (refusal, jailbreak susceptibility); it tests probe accuracy on activations with the discovered subspace projected out.

## Methodology

For each representative layer (early=L4, middle=L14, final=L25) and each subspace definition from Experiment 011 (within-class PCA, between-class paired-difference PCA), the top-k components (k ∈ [1, 2, 5, 10, 20]) were projected out of held-out benign/unsafe activations (test split reproduced with Experiment 011's exact seed/test_size). Two evaluations were run on the ablated activations: (a) the **original, frozen** Experiment-011 probe weight vector, and (b) a **freshly re-fit** logistic regression trained on the ablated training split. Both were compared against ablating a random k-dimensional subspace (20 trials, averaged) as a dimensionality-matched control.

## Experimental Setup

- Model: `Qwen/Qwen2.5-1.5B-Instruct` (activations reused from Experiment 011, no generation performed)
- k values: [1, 2, 5, 10, 20]
- Subspace types: ['within', 'between'] + random_control
- Bootstrap resamples for CIs: 2000
- Random-subspace control trials: 20
- Test split: seed=42, test_size=0.2 (matches Experiment 011)

## Results

**Read this section's frozen-probe numbers with the methodological note below in mind.** Two tables are given for the frozen evaluation: the raw original threshold, and the recalibrated version (same weight vector, refit threshold). Where they diverge sharply, prefer the recalibrated numbers and the Interpretation section, which uses those.

### Frozen-probe accuracy — RAW (original Exp. 011 threshold, unadjusted)

| Layer | Subspace | k=1 | k=2 | k=5 | k=10 | k=20 |
|---|---|---|---|---|---|---|
| early (L4) | within | 1.000 | 0.975 | 0.500 | 0.500 | 0.500 |
| early (L4) | between | 0.950 | 0.787 | 0.500 | 0.500 | 0.500 |
| early (L4) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| middle (L14) | within | 0.500 | 0.500 | 0.500 | 0.500 | 0.500 |
| middle (L14) | between | 0.500 | 0.500 | 0.500 | 0.500 | 0.500 |
| middle (L14) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| final (L25) | within | 0.500 | 0.500 | 0.500 | 0.500 | 0.500 |
| final (L25) | between | 0.500 | 0.500 | 0.500 | 0.500 | 0.500 |
| final (L25) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |

### Frozen-DIRECTION accuracy — RECALIBRATED (same weight vector, refit threshold)

| Layer | Subspace | k=1 | k=2 | k=5 | k=10 | k=20 |
|---|---|---|---|---|---|---|
| early (L4) | within | 1.000 | 1.000 | 0.588 | 0.688 | 0.575 |
| early (L4) | between | 0.988 | 0.787 | 0.537 | 0.613 | 0.588 |
| early (L4) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| middle (L14) | within | 0.575 | 0.525 | 0.525 | 0.487 | 0.500 |
| middle (L14) | between | 0.463 | 0.412 | 0.500 | 0.500 | 0.500 |
| middle (L14) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| final (L25) | within | 0.438 | 0.463 | 0.375 | 0.512 | 0.475 |
| final (L25) | between | 0.400 | 0.400 | 0.338 | 0.450 | 0.463 |
| final (L25) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |

### Re-fit probe accuracy (new classifier on ablated activations, C=0.01)

| Layer | Subspace | k=1 | k=2 | k=5 | k=10 | k=20 |
|---|---|---|---|---|---|---|
| early (L4) | within | 1.000 | 0.975 | 0.625 | 0.637 | 0.475 |
| early (L4) | between | 0.950 | 0.762 | 0.500 | 0.550 | 0.400 |
| early (L4) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| middle (L14) | within | 0.575 | 0.487 | 0.512 | 0.500 | 0.375 |
| middle (L14) | between | 0.450 | 0.450 | 0.475 | 0.388 | 0.287 |
| middle (L14) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| final (L25) | within | 0.225 | 0.225 | 0.188 | 0.138 | 0.087 |
| final (L25) | between | 0.163 | 0.125 | 0.113 | 0.100 | 0.062 |
| final (L25) | random_control | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |

## Methodological Note: two evaluation artifacts and how they were handled

**Raw frozen-probe accuracy can saturate at exactly the test set's class balance (e.g. 0.500) even when real signal survives ablation.** If the removed component carries much of the activations' overall mean, ablation rigidly shifts every score by a constant; the original fixed intercept — calibrated for the pre-ablation distribution — can then push every test point to the same side of the decision boundary, producing a degenerate constant-class prediction. This looks identical to 'no separability survives' in the accuracy column alone, even when AUC (or a recalibrated threshold) shows real ranking signal remains. `frozen_recalibrated` fixes this by keeping the weight vector frozen but refitting a 1-D threshold on the ablated training projections.

**Re-fit probe accuracy can fall below chance (not just to chance) when it is measuring overfitting rather than information content.** With `n_train~320` and `hidden_size` in the ~1500 range, ablating even 20 dimensions leaves a severely underdetermined (`p >> n`) regime where any training-set labeling is perfectly linearly separable by chance. Weak regularization fits that chance structure and can generalize worse than random guessing — a pattern that would otherwise be mistaken for strong evidence against redundancy. `refit_probe` uses `refit_probe_C=0.01` (strong L2) specifically to keep this measurement honest; if you see accuracy well below 0.5 that continues to worsen with k even at this regularization strength, treat it as a sign to regularize further or reduce dimensionality before fitting, not as a substantive finding.

## Interpretation

At the middle representative layer, within-class subspace, removing the largest tested subspace (k=20) leaves **recalibrated** frozen-direction accuracy at **0.500** (baseline 1.000) while a freshly re-fit, strongly regularized probe on the same ablated activations reaches **0.375** — a gap of **-0.125**. A small gap indicates that once this subspace is removed, no comparably strong linear signal remains — consistent with the discovered subspace being close to causally necessary for the *linear* representation of policy information at this layer (within the scope of what this notebook tests).

Compare each subspace-ablation row against its `random_control` row in the tables above: if random k-dimensional ablation causes a similar accuracy drop, the effect is largely a generic consequence of removing *any* k dimensions from a high-dimensional representation, not evidence that this particular subspace is special. See `statistics/statistics.json` for McNemar p-values and Cohen's h effect sizes quantifying this per condition.

## Figures

- `figures/fig1_frozen_probe_accuracy_vs_k.png` — RAW frozen (original) probe accuracy vs. components removed — see Methodological Note before interpreting.
- `figures/fig1b_frozen_recalibrated_accuracy_vs_k.png` — RECALIBRATED frozen-direction accuracy vs. components removed — the more reliable read on whether the direction still separates the classes.
- `figures/fig2_refit_probe_accuracy_vs_k.png` — Re-fit (regularized) probe accuracy vs. components removed — tests whether information is destroyed or redundant.
- `figures/fig3_combined_tradeoff_frozen_vs_refit.png` — Recalibrated-frozen vs. re-fit accuracy trade-off at the middle layer, within-class subspace.
- `figures/fig4_layer_by_k_heatmap_frozen_within.png` — Layer x k heatmap of recalibrated frozen-direction accuracy drop, within-class subspace.
- `figures/fig4b_layer_by_k_heatmap_frozen_raw_within.png` — Same heatmap using the RAW (non-recalibrated) accuracy drop, for comparison.
- `figures/fig5_within_vs_between_comparison_fixed_k.png` — Within- vs. between-class subspace comparison at k=5.

## Discussion

This experiment establishes a *representational* causal claim: whether the Experiment-011 policy subspace is necessary for linear probes to separate benign/unsafe activations. It does not establish, and should not be read as establishing, anything about whether the model's generation-time behavior (refusals, compliance) causally depends on this subspace — that would require an intervention during generation, which this notebook deliberately does not perform.

## Limitations

- Held-out test sets are small (governed by Experiment 011's original prompt-set size), so per-condition confidence intervals may be wide — consult `statistics.json` rather than point estimates alone.
- Linear probes only test *linear* separability; a nonlinear probe might recover information from ablated activations that a logistic regression cannot, understating redundancy.
- Results are specific to `Qwen/Qwen2.5-1.5B-Instruct` and the Experiment 011 prompt distribution; they may not generalize to other models or more adversarial/out-of-distribution unsafe prompts.
- No claim is made here about whether this subspace is the *only* safety-relevant mechanism in the model — only whether it's necessary for linear separability in the tested activations.

## Future Work

- If a future experiment does test generation-time behavioral effects of subspace intervention, it should be scoped and reviewed separately from this notebook, with explicit consideration of dual-use risk given that the same technique doubles as a refusal-ablation method on open-weight models.
- Extend the redundancy check with nonlinear probes (e.g. small MLP) to see if the frozen/re-fit gap narrows or widens.
- Repeat across model scale (7B/14B Qwen2.5) to see whether redundancy increases with model capacity.
