# NPS Experiment 010 — REPORT

Generated: 2026-06-26T03:42:13.970057

## Experiment Summary

- Model: TinyLlama/TinyLlama-1.1B-Chat-v1.0
- Total prompts: 500
- Max new tokens: 80
- Device: cpu
- Total result rows: 58356

## Research Questions

### RQ1: Do jailbreak prompts produce significantly larger policy-state drift?

**Layer: early**
  - benign vs harmful: p=0.0162, Cohen's d=0.2416
  - benign vs jailbreak: p=0.0000, Cohen's d=0.9398
  - harmful vs jailbreak: p=0.0000, Cohen's d=0.6004

**Layer: mid**
  - benign vs harmful: p=0.0096, Cohen's d=0.2603
  - benign vs jailbreak: p=0.0000, Cohen's d=0.8044
  - harmful vs jailbreak: p=0.0002, Cohen's d=0.4957

**Layer: late**
  - benign vs harmful: p=0.0000, Cohen's d=0.4946
  - benign vs jailbreak: p=0.0000, Cohen's d=1.4794
  - harmful vs jailbreak: p=0.0000, Cohen's d=1.0374

**Layer: final**
  - benign vs harmful: p=0.0003, Cohen's d=0.3660
  - benign vs jailbreak: p=0.0000, Cohen's d=1.5751
  - harmful vs jailbreak: p=0.0000, Cohen's d=1.4669

### RQ2: At what layer does drift first emerge?

See fig2_layer_comparison for visual layer-by-layer projection evolution.

### RQ3: Does drift occur before unsafe text generation?

**Refusal and unsafe generation rates:**

| category   |   refusal |   unsafe |
|:-----------|----------:|---------:|
| benign     |       0   |      0.5 |
| harmful    |       0.5 |      1.5 |
| jailbreak  |       0   |      5   |

Cross-reference token_index of first large drift event vs.
the token index at which unsafe content first appears in the trajectory.

### RQ4: Can measured drift serve as a neural firewall basis?

If drift is both early and large for jailbreak prompts (RQ1+RQ2), a real-time threshold on P(h) could trigger a safety interrupt before harmful text is generated. See projection_statistics.csv for per-prompt delta_p distributions to calibrate such a threshold.

## Outputs

- `projection_results.csv` — per-token scalar projections
- `projection_statistics.csv` — per-prompt summary statistics
- `projection_summary.csv` — group-level statistics & comparisons
- `figures/` — all publication figures (PNG + PDF)
- `experiment_metadata.json`
- `NPS_Exp010_Results.zip`