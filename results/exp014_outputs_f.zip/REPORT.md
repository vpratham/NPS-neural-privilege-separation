# Experiment 014 — Policy Memory as Active Intervention: Report

**Policy artifact source:** `trained_exp013_checkpoint:policy_memory_default.pt`
**Policy direction:** grounded=True, n_prompts=480, n_unsafe=60, n_safe=420
**Dataset source:** `exp013_prompt_dataset`
**Model:** Qwen/Qwen2.5-1.5B-Instruct (frozen)
**Intervention layer (primary, matches Exp013 training layer):** 14
**Layers swept:** [6, 10, 14]
**Alphas:** [0.0, 0.25, 0.5, 1.0, 2.0, 4.0]

## Headline results
- Baseline (alpha=0) refusal rate: **0.554**
- Peak refusal rate under reinforcement: **0.562**
- Max refusal-rate drop under suppression: **0.027**
- Capability (exact-match-vs-baseline) drop from alpha=0 to max alpha: **-0.739**

## Interpretation
If reinforcement increases refusal rate on unsafe/jailbreak prompts monotonically with alpha, and suppression decreases it, while benign-task outputs stay close to their own alpha=0 baseline at moderate alpha, this is causal evidence that the policy representation learned passively in Experiment 013 is *actively steerable* — the Explicit Policy Memory is not just a readout of policy state but a direction the model's generation is causally sensitive to when reintroduced into the residual stream at the same layer (14) it was trained to read from. A capability collapse at the same alpha where refusal rate saturates would indicate the direction is a generic norm/coherence perturbation rather than policy-specific, and should be reported as a negative/mixed result rather than reframed as success.

## Representational analysis summary
- Mean cosine(original, intervened) at layer 14: 1.000
- Mean cosine(intervened, policy direction): 0.034
- UMAP available: True

## Files
- `generations.csv`, `layer_sweep_generations.csv` — raw per-generation records
- `capability_eval.csv` — benign-task drift-from-baseline scores per alpha
- `policy_direction.pt`, `policy_direction_meta.json` — the injected vector and its provenance
- `tables/*.csv` / `.tex` — statistical analysis and both ablation axes
- `representational_analysis.json`, `figures/*.png`, `figures/*.pdf`

## Caveats
- Policy artifact source is `trained_exp013_checkpoint:policy_memory_default.pt`. If this is not `trained_exp013_checkpoint:...`, treat all numbers as a pipeline smoke test only.
- The 64-d memory-space policy direction is projected into the 1536-d residual stream via a **linear approximation** (transposed encoder weights, skipping the GELU/LayerNorm nonlinearities in between) — not an exact inverse of the encoder.
- The `linear_untrained` arm of the projection-head ablation has no corresponding trained checkpoint in Experiment 013 and characterizes mechanism sensitivity only.
- Refusal detection uses a keyword/regex heuristic; borderline or hedged compliance is not distinguished from full compliance.
- Capability retention is measured as drift from each prompt's own alpha=0 output (no gold references exist in Exp013's dataset for these categories), not against an external ground truth.